package com.iiht.tweetapp.repository;


import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.iiht.tweetapp.model.UserData;


@Repository
public interface UserRepository extends MongoRepository<UserData, String> {

}