package com.iiht.tweetapp.model;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Document(collection = "tweet_details")
public class TweetDetails {
	
	@Id
	private UUID id;
	
	private String handleName;
	 
	private String message;
	
	private LocalDateTime time;
	
	private String username;
	
	private int likes;
	
	private List<String> replies;
	
	@JsonIgnore
	private boolean Status;

}
