package com.iiht.tweetapp.repository;

import java.util.Optional;
import java.util.UUID;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.iiht.tweetapp.model.TweetDetails;

@Repository
public interface TweetRepository extends MongoRepository<TweetDetails, UUID> {
	Optional<TweetDetails> findByUsername(String username);
}
